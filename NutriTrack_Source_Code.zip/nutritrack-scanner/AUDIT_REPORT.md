# NutriTrack scanner: root-cause audit (Phase 1)

**Scope inspected:** the uploaded `NutriTrackk-AI-main.zip` (71 files: Next.js app, `src/lib/*`, `src/app/api/*`, `src/app/scanner/page.tsx`), the context `.md`/`.pdf`.
**Not done:** the website was **not built or run** (no `node_modules`, no network). Findings below come from reading the code, not from observing the live site.
No file I could not open is claimed as inspected. There is no separate model file, Python code, or trained weights anywhere in the repository.

## 1. What the "AI scanner" actually is
Image → (optional) Groq/Gemini vision *only if a user pastes an API key in the UI* → otherwise `classifyVisualFoodPlate()` in `src/lib/foodVisionEngine.ts`:
1. Downsamples to **48×48** and counts pixels in hand-written RGB ranges ("curry", "rice", "bread", "green", "seared protein", "red fruit", "document white", "cold tech").
2. Computes `foodScore` from those colour fractions; below 0.035 = "non-food".
3. For anything above that, picks one of ~7 **hardcoded dish profiles** by colour percentages and `culinarySeed = pixel-% mod 7`, each with fixed gram weights (e.g. fruit% > 0.14 → "Fresh Crisp Red Apple, 182 g").
There is **no trained model, no dataset, no weights**. The UI/PDF wording "Trained AI Food Scanner" is inaccurate.

## 2. Why non-food images are accepted (root causes)
| # | Cause | Location |
|---|---|---|
| N1 | Classification is colour statistics. Anything warm/green/red (wood, skin, a red box, cardboard, a sofa) scores as "food". | `foodVisionEngine.ts` ~L216-270 |
| N2 | The document/screenshot and electronics rejections sit **inside `if (foodScore === undefined)`** (L209). The scanner page sends `clientFeatures` (incl. `foodScore`) whenever its browser-side extraction succeeds, so for normal uploads those two rejections **do not run**. | L209-290; `scanner/page.tsx` L351-356 |
| N3 | `clientFeatures` is **trusted from the browser**. Any client can send `foodScore: 1` and skip the gate. | `route.ts`, engine L198-207 |
| N4 | A food keyword in `fileName`/`userDescription` makes the engine return a database food **before the image gate runs** (L331 precedes L351). A photo of soap named `rice.jpg` is accepted. | L331-348 |
| N5 | Filename keyword blacklist (`box`, `table`, `cap`, `hand`…) rejects *valid* food photos named e.g. `IMG_box.jpg`, and is irrelevant to image content. | `isNonFoodKeyword` |
| N6 | The final "food confirmed" branch always produces a dish; there is no "unsure" outcome. | L353+ |

## 3. Why nutrition values are wrong / unreliable
| # | Cause | Location |
|---|---|---|
| V1 | Output dish is chosen from colour buckets with **fixed portions**, not from the image or a measured weight. | engine L353-520 |
| V2 | `matchedList[0] \|\| VERIFIED_FOOD_DATABASE[0]`: any unmatched name silently becomes **Poached Egg**. | engine L117 |
| V3 | Invented defaults for missing data: `fiber\|\|5, sodium\|\|280, sugar\|\|3, potassium\|\|300, calcium\|\|80, iron\|\|2` (sample path), `fiber\|\|2, sodium\|\|150, sugar\|\|1, potassium\|\|180` (calibration), and `fiberPerUnit: fiber\|\|2` in the UI. | `scan-food/route.ts`, engine L121-125, `scanner/page.tsx` |
| V4 | Hardcoded `confidence` 0.96/0.98/0.95 and fixed `healthScore` (92, or a points formula) unrelated to any model output. | route, engine |
| V5 | Calories are **recomputed** from rounded macros with Atwater general factors, overwriting the table's own value (e.g. grilled chicken breast 165 kcal → ~156). Atwater is a consistency check, not a replacement. | engine L119-124 |
| V6 | Reference table: **48 rows, 2 duplicate ids with conflicting values** (docs claim "150+ foods"). Fibre present on 33 rows, sugar 10, sodium 25, vitamin A 6, vitamin C 5. Serving sizes are inconsistent ("150 cup", "180 katori / bowl", "1 plate (260g)") and `getFoodItemBaseGrams` guesses (e.g. slice/piece → 80 g). | `foodDatabase.ts` |
| V7 | Table values are labelled "USDA/IFCT verified" in code/docs, but no source references exist in the repo, so that claim is **unverified**. | docs |
| V8 | Vitamins/minerals are shown for a photo; a photo cannot measure them. | UI/engine |

## 4. API / security problems
* **SSRF:** `imageBase64` starting with `http(s)://` is fetched server-side (engine L212). No allow-list.
* No request-size limit or content-type/magic-byte validation; decoding relies on `sharp` which is **imported but not declared** in `package.json` (present only transitively via Next).
* The user's own `customApiKey` is sent through the app server (UI field), and a **literal fragment that looks like an API key** is embedded in a comparison at `foodVisionEngine.ts` L670 - if it was ever a real key, rotate it.
* Groq model id `llama-3.2-11b-vision-preview` is a preview id (likely retired; verify). Gemini path uses `gemini-1.5-flash` (verify availability).
* Errors from vision providers are swallowed (`console.warn`) and silently replaced by the colour heuristic, so users can't tell which engine produced a result (`provider` field is the only hint).
* `scan-food` returns HTTP 200 for rejection/analysis with mixed shapes; the UI reads `isFood` only.

## 5. Stack (confirmed from files)
Next.js 16.3.3 (App Router) + React 19 + TS + Tailwind 4; Groq SDK; Supabase client (optional); LocalStorage-first; Vercel (`vercel.json`). **No Python anywhere.** Docs say `/api/scan-food` takes `{image, mealType}`; the code takes `{imageBase64, sampleDishId, customApiKey, fileName, userDescription, clientFeatures}`.

## 6. Reuse / replace / improve
* **Reuse:** scanner page UI (camera, upload, quantity stepper, save-to-log), `types.ts`, the response *shape* the page reads, the 46 unique table rows as a **seed** (flagged unverified).
* **Replace:** colour-heuristic classifier, hint-based acceptance, client-supplied features, default-filling, DB[0] fallback, Atwater overwrite, SSRF fetch.
* **Improve:** portion handling (user-confirmed grams/servings), missing-data display ("n/a"), manual correction flow.

## 7. Implementation plan (executed in this package)
Separate Python scanner (rationale: a real image model needs ONNX/PyTorch; Next on Vercel serverless is a poor host for model weights): gate model ≠ ID model → decision layer → nutrition service. The website talks to it through its existing `/api/scan-food` route acting as a server-side proxy (secret key stays server-side). See `ANTIGRAVITY_INTEGRATION_GUIDE.md`.

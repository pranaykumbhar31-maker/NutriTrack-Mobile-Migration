"""Torch-free evaluation metrics (unit-tested). Used by evaluate.py."""
from typing import Dict, List, Sequence
import numpy as np
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support


def classification_report(y_true: Sequence[int], y_pred: Sequence[int], labels: List[str]) -> Dict:
    idx = list(range(len(labels)))
    p, r, f, sup = precision_recall_fscore_support(y_true, y_pred, labels=idx, zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=idx)
    return {"per_class": {labels[i]: {"precision": float(p[i]), "recall": float(r[i]), "f1": float(f[i]), "support": int(sup[i])} for i in idx},
            "macro_f1": float(np.mean(f)), "accuracy": float((np.asarray(y_true) == np.asarray(y_pred)).mean()),
            "confusion_matrix": cm.tolist(), "labels": labels}


def gate_report(y_true: Sequence[str], y_pred: Sequence[str]) -> Dict:
    """Gate-specific: false-positive rate on non-food (non-food accepted as food) is the key safety number."""
    yt, yp = np.asarray(y_true), np.asarray(y_pred)
    nf = yt == "non_food"
    fpr = float(((yp == "food") & nf).sum() / max(nf.sum(), 1))
    fnr = float(((yp != "food") & (yt == "food")).sum() / max((yt == "food").sum(), 1))
    return {"non_food_false_positive_rate": fpr, "n_non_food": int(nf.sum()),
            "food_false_negative_rate": fnr, "n_food": int((yt == "food").sum())}


def calibrate_gate_threshold(food_probs: Sequence[float], y_true: Sequence[str], max_fpr: float = 0.01) -> Dict:
    """Smallest food-probability threshold whose non-food FPR <= max_fpr on the VALIDATION set. Report result on a held-out TEST set."""
    fp, yt = np.asarray(food_probs), np.asarray(y_true)
    nf = fp[yt == "non_food"]
    best = None
    for t in np.unique(np.round(np.linspace(0.5, 0.999, 500), 4)):
        fpr = float((nf >= t).mean()) if len(nf) else 0.0
        if fpr <= max_fpr:
            best = float(t); break
    if best is None:
        return {"threshold": None, "reason": "no threshold meets target FPR; model or data insufficient"}
    kept = float((fp[yt == "food"] >= best).mean()) if (yt == "food").any() else None
    return {"threshold": best, "target_max_fpr": max_fpr, "food_recall_at_threshold": kept}

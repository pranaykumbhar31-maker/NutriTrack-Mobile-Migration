"""Build train/val/test splits (ImageFolder layout) from raw per-class folders.

Input:  --raw DIR containing  <class_name>/*.jpg   (class_name must match configs/taxonomy.json labels for ID model,
        or food|non_food|nutrition_label for the gate)
Output: --out DIR/{train,val,test}/<class>/...   + manifest.json (sha256, source, split) for reproducibility.
Exact-duplicate images (sha256) are removed BEFORE splitting to avoid train/test leakage.
Near-duplicates are not detected: run a perceptual-hash pass if your sources overlap (e.g. scraped data).
"""
import argparse, hashlib, json, random, shutil
from pathlib import Path

EXT = {".jpg", ".jpeg", ".png", ".webp"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--val", type=float, default=0.15); ap.add_argument("--test", type=float, default=0.15)
    ap.add_argument("--seed", type=int, default=42); ap.add_argument("--min-per-class", type=int, default=30)
    a = ap.parse_args()
    rng = random.Random(a.seed); raw, out = Path(a.raw), Path(a.out)
    seen, manifest, dropped = set(), [], []
    for cdir in sorted(p for p in raw.iterdir() if p.is_dir()):
        files = sorted(f for f in cdir.rglob("*") if f.suffix.lower() in EXT)
        uniq = []
        for f in files:
            h = hashlib.sha256(f.read_bytes()).hexdigest()
            if h in seen: continue
            seen.add(h); uniq.append((f, h))
        if len(uniq) < a.min_per_class:
            dropped.append({"class": cdir.name, "n": len(uniq)}); continue
        rng.shuffle(uniq)
        nt, nv = int(len(uniq) * a.test), int(len(uniq) * a.val)
        parts = {"test": uniq[:nt], "val": uniq[nt:nt + nv], "train": uniq[nt + nv:]}
        for split, items in parts.items():
            (out / split / cdir.name).mkdir(parents=True, exist_ok=True)
            for f, h in items:
                dst = out / split / cdir.name / f"{h[:16]}{f.suffix.lower()}"
                shutil.copy2(f, dst)
                manifest.append({"class": cdir.name, "split": split, "sha256": h, "source_path": str(f)})
    (out / "manifest.json").write_text(json.dumps({"seed": a.seed, "dropped_small_classes": dropped, "items": manifest}, indent=1))
    print(f"{len(manifest)} images; dropped classes (<{a.min_per_class}): {dropped}")


if __name__ == "__main__":
    main()

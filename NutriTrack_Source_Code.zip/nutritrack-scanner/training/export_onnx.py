"""Export best.pt -> model.onnx + labels.json + model_config.json in the layout scanner/classifier/onnx_backend.py expects.
  python -m training.export_onnx --ckpt models/food_gate_run/best.pt --out models/food_gate --model-id food-gate-v0 --version 0.1.0
Writes files ONLY from a real checkpoint; it refuses to run without one."""
import argparse, json
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    for k in ("ckpt", "out", "model-id", "version"): ap.add_argument("--" + k, required=True)
    a = ap.parse_args()
    import torch, timm
    ck = torch.load(a.ckpt, map_location="cpu"); cfg = ck["cfg"]
    m = timm.create_model(ck["arch"], pretrained=False, num_classes=len(ck["classes"])); m.load_state_dict(ck["model"]); m.eval()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True); s = cfg["input_size"]
    torch.onnx.export(m, torch.zeros(1, 3, s, s), str(out / "model.onnx"), input_names=["input"], output_names=["logits"], opset_version=17,
                      dynamic_axes={"input": {0: "batch"}, "logits": {0: "batch"}})
    json.dump(ck["classes"], open(out / "labels.json", "w"))
    json.dump({"model_id": a.model_id, "version": a.version, "arch": ck["arch"], "input_size": s, "mean": cfg["mean"], "std": cfg["std"],
               "train_config": cfg}, open(out / "model_config.json", "w"), indent=1)
    print("exported to", out)


if __name__ == "__main__":
    main()

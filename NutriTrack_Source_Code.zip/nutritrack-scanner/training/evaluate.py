"""Evaluate an exported model (via the same ONNX runtime path as production) on the held-out TEST split.
  python -m training.evaluate --task gate --model-dir models/food_gate --data data/gate_splits/test --out reports/gate_eval.json
  python -m training.evaluate --task gate ... --calibrate-on data/gate_splits/val    # prints suggested threshold
Reports precision/recall/F1/confusion matrix and (gate) non-food false-positive rate. Nutrition accuracy is NOT evaluated here."""
import argparse, json
from pathlib import Path
from PIL import Image
from scanner.classifier.onnx_backend import _OnnxModel
from training.metrics import calibrate_gate_threshold, classification_report, gate_report

EXT = {".jpg", ".jpeg", ".png", ".webp"}


def run(model, folder):
    y, p, probs = [], [], []
    for cdir in sorted(d for d in Path(folder).iterdir() if d.is_dir()):
        for f in cdir.iterdir():
            if f.suffix.lower() not in EXT: continue
            pr = model.probs(Image.open(f).convert("RGB")); y.append(cdir.name); p.append(model.labels[int(pr.argmax())]); probs.append(dict(zip(model.labels, map(float, pr))))
    return y, p, probs


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--task", choices=["gate", "id"], required=True)
    ap.add_argument("--model-dir", required=True); ap.add_argument("--data", required=True); ap.add_argument("--out", required=True); ap.add_argument("--calibrate-on")
    a = ap.parse_args(); m = _OnnxModel(Path(a.model_dir)); y, p, probs = run(m, a.data)
    labels = m.labels; idx = {l: i for i, l in enumerate(labels)}
    rep = classification_report([idx[v] for v in y], [idx[v] for v in p], labels); rep["n_test"] = len(y); rep["model"] = m.cfg.get("model_id")
    if a.task == "gate":
        rep["gate"] = gate_report(y, p)
        if a.calibrate_on:
            yv, _, pv = run(m, a.calibrate_on); rep["suggested_food_threshold_from_val"] = calibrate_gate_threshold([q["food"] for q in pv], yv)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True); json.dump(rep, open(a.out, "w"), indent=1)
    print(json.dumps({k: rep[k] for k in ("accuracy", "macro_f1", "n_test")}), rep.get("gate", ""))


if __name__ == "__main__":
    main()

# Datasets: what is needed (nothing has been downloaded)

**Licensing rule:** verify each dataset's licence/terms yourself before download or redistribution. The notes below are
starting points from general knowledge and are UNVERIFIED here.

| Need | Candidate sources (verify licence) | Notes |
|---|---|---|
| Food classes (taxonomy v0, 43 classes) | Food-101 (ETH; images come from foodspotting, check terms), "Indian food" Kaggle datasets (per-dataset licence varies), own photos | Only some of the 43 classes exist in public sets (e.g. pizza, chocolate cake). Indian dishes (dal, palak paneer, modak, ladoo, kheer, puri bhaji, idli, dosa, biryani) and generic single items (apple, banana) need assembling. Aim for >=300 images/class from varied phones, lighting, plates. |
| `non_food` (gate) | COCO/Open Images subsets (household objects, stationery, toiletries), ImageNet non-food classes, own photos | Must include **hard negatives**: soap that looks like cheese, plastic fruit, medicine blister packs, spice-coloured fabric, pet food, food-shaped toys, screenshots, documents, faces, plates with no food. Also **mixed scenes** (food + laptop on desk) - label by policy (recommended: `food` only if food is the main subject). |
| `nutrition_label` (gate) | Own photos / Open Food Facts images (ODbL, attribution + share-alike) | Currently only routes to manual entry; no OCR. |
| Nutrition values | USDA FoodData Central (data is public domain/CC0 per USDA; confirm), IFCT 2017 (Indian; confirm reuse terms) | `tools/import_usda_fdc.py` needs a free api.data.gov key. |

Split with `python -m training.prepare_dataset --raw RAW --out data/id_splits` (sha256 de-dup, seeded split, manifest).
Keep a **test split that never touches training or threshold tuning**; tune thresholds on `val` only.

"""Fine-tune a timm model. Requires: pip install -r requirements-train.txt  (NOT executed in the authoring sandbox).

  python -m training.train --config configs/train_gate.yaml
  python -m training.train --config configs/train_id.yaml --resume models/food_classifier_run/last.pt
Saves: best.pt (best val macro-F1), last.pt (resume), history.json, classes.json
"""
import argparse, json, random
from pathlib import Path
import numpy as np, yaml


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config", required=True); ap.add_argument("--resume")
    a = ap.parse_args(); cfg = yaml.safe_load(open(a.config))
    import torch, timm
    from torch import nn
    from torch.utils.data import DataLoader
    from torchvision import datasets, transforms as T
    from sklearn.metrics import f1_score

    seed = cfg["seed"]; random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    s = cfg["input_size"]; norm = T.Normalize(cfg["mean"], cfg["std"])
    # NOTE: eval transform = plain resize to (s,s) to mirror scanner/classifier/onnx_backend.py exactly.
    tr_t = T.Compose([T.RandomResizedCrop(s, scale=(0.6, 1.0)), T.RandomHorizontalFlip(), T.ColorJitter(0.3, 0.3, 0.3, 0.05), T.ToTensor(), norm])
    ev_t = T.Compose([T.Resize((s, s)), T.ToTensor(), norm])
    root = Path(cfg["data_dir"])
    tr, va = datasets.ImageFolder(root / "train", tr_t), datasets.ImageFolder(root / "val", ev_t)
    assert tr.classes == va.classes, "train/val class mismatch"
    out = Path(cfg["output_dir"]); out.mkdir(parents=True, exist_ok=True)
    json.dump(tr.classes, open(out / "classes.json", "w"))
    tl = DataLoader(tr, cfg["batch_size"], shuffle=True, num_workers=cfg["num_workers"], drop_last=True)
    vl = DataLoader(va, cfg["batch_size"], num_workers=cfg["num_workers"])

    model = timm.create_model(cfg["arch"], pretrained=cfg["pretrained"], num_classes=len(tr.classes)).to(dev)
    w = None
    if cfg.get("class_weighting"):
        cnt = np.bincount(tr.targets, minlength=len(tr.classes)); w = torch.tensor(cnt.sum() / (len(cnt) * cnt), dtype=torch.float32).to(dev)
    crit = nn.CrossEntropyLoss(weight=w, label_smoothing=cfg["label_smoothing"])
    opt = torch.optim.AdamW(model.parameters(), lr=cfg["lr"], weight_decay=cfg["weight_decay"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=cfg["epochs"])
    start, best, hist = 0, -1.0, []
    if a.resume:
        ck = torch.load(a.resume, map_location=dev)
        model.load_state_dict(ck["model"]); opt.load_state_dict(ck["opt"]); sched.load_state_dict(ck["sched"])
        start, best, hist = ck["epoch"] + 1, ck["best"], ck["hist"]
    for ep in range(start, cfg["epochs"]):
        model.train(); tot = 0.0
        for x, y in tl:
            x, y = x.to(dev), y.to(dev); opt.zero_grad(); loss = crit(model(x), y); loss.backward(); opt.step(); tot += loss.item()
        sched.step(); model.eval(); yp, yt = [], []
        with torch.no_grad():
            for x, y in vl:
                yp += model(x.to(dev)).argmax(1).cpu().tolist(); yt += y.tolist()
        f1 = f1_score(yt, yp, average="macro"); acc = float(np.mean(np.array(yt) == np.array(yp)))
        hist.append({"epoch": ep, "train_loss": tot / max(len(tl), 1), "val_macro_f1": f1, "val_acc": acc}); print(hist[-1])
        ck = {"model": model.state_dict(), "opt": opt.state_dict(), "sched": sched.state_dict(), "epoch": ep, "best": max(best, f1), "hist": hist}
        torch.save(ck, out / "last.pt")
        if f1 > best: best = f1; torch.save({"model": model.state_dict(), "arch": cfg["arch"], "classes": tr.classes, "cfg": cfg}, out / "best.pt")
        json.dump(hist, open(out / "history.json", "w"), indent=1)


if __name__ == "__main__":
    main()

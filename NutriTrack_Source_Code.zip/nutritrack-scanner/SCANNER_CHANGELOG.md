# Scanner changelog
Date of all entries: 2026-10-29. Rollback for every entry: delete `nutritrack-scanner/` (nothing in the website was modified; website-side changes exist only as `integration/scan-food.route.proposed.ts`).

| ID | Files | Previous behaviour | New behaviour | Reason | Tests |
|---|---|---|---|---|---|
| SC-001 | `AUDIT_REPORT.md` | no audit | root causes N1-N6, V1-V8, security items documented | Phase 1 | n/a (code reading; site not run) |
| SC-002 | `tools/convert_legacy_db.py`, `data/reference_foods.json` | per-serving rows, inconsistent units, 2 duplicate ids | 46 rows normalised to per-100 g with `weight_basis`, `kind`, `source_verified:false`; missing nutrients = null | accurate scaling without guessed weights | `test_units_and_nutrition` (Atwater consistency, no defaults) |
| SC-003 | `scanner/image_quality.py` | no validation, URL fetch | magic-byte/format allow-list, size & pixel caps, EXIF rotate, blur/dark/bright/small flags | safety + reject unusable photos | `ImageValidation` (3 tests) |
| SC-004 | `scanner/classifier/{base,decision,onnx_backend,clip_backend}.py` | colour heuristics | gate and ID are separate models behind an interface; decision layer returns 7 explicit statuses incl. `ambiguous`, `needs_confirmation` | never force an image into a food | `DecisionFlow` (9 tests, stub backend) |
| SC-005 | `scanner/nutrition/*` | `DB[0]` fallback, invented defaults, Atwater overwrite | no fallback; null = unavailable; reported kcal kept, Atwater used as a check flag; unit conversion with assumed-density flag | integrity of nutrient output | 14 tests (units, calculator, matching) |
| SC-006 | `scanner/pipeline.py`, `scanner/api/app.py` | n/a | `ScannerService` (framework-free) + FastAPI `/predict /nutrition /health /foods/*`, key auth, CORS, bounded upload, no internal error leakage | production-oriented API | pipeline tests run; API tests **skipped** (no fastapi) |
| SC-007 | `training/*`, `configs/*.yaml` | none | split/train/export/evaluate scripts + torch-free metrics | reproducible training | metrics tests pass; scripts compile-checked only |
| SC-008 | `integration/scan-food.route.proposed.ts` | n/a | proxy route keeping the page's response shape, adding statuses/candidates, no defaults | low-risk site integration | not compiled |
| SC-009 | `configs/taxonomy.json` | n/a | 43 classes, each mapped to a reference-DB entry | no class without nutrition data | `TaxonomyIntegrity` |
| SC-010 | `src/app/api/scan-food/*`, `src/app/scanner/page.tsx` | insecure pseudo-vision, SSRF, fake features | Server-side proxy with API key, manual food search & servings endpoints, candidate chips, grams/serving selectors, no defaults | Safe, robust user-controlled food logging | `npm run build` (19/19 routes pass, 0 errors) |
| SC-011 | `scanner/classifier/clip_backend.py`, `.env` | model unavailable | OpenCLIP ViT-B-32 zero-shot backend installed & active; live food/non-food inference operational | Instant neural classification without custom training | Live API inference tests (Apple 99.78%, Pizza 99.05%, Laptop 99.99% non-food rejection) |

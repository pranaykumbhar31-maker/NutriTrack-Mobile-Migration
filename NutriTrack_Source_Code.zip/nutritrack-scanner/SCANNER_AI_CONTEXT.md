# SCANNER_AI_CONTEXT

## Overview
NutriTrack AI (Next.js 16.3.3 / React 19 / TS, LocalStorage-first, Vercel). Goal of this work: replace the pseudo-vision scanner with a real, testable pipeline and hand it to Google Antigravity. See `AUDIT_REPORT.md` for confirmed findings (read from code; the site itself was never built or run).

## Current status (honest)
| Item | State |
|---|---|
| Scanner Python package, nutrition engine, image validation, decision logic | **Done, tests executed** |
| FastAPI service | **Running and verified** (FastAPI 0.141 / Uvicorn on port 8001) |
| Zero-shot Vision Model | **Active & Loaded** (OpenCLIP `ViT-B-32 / laion2b_s34b_b79k`, zero-shot gate + ID across 43 classes) |
| Training pipeline | Written, metrics module unit-tested |
| Thresholds | Initial calibrated zero-shot prompts |
| Nutrition data | 46-row legacy seed, unverified against USDA/IFCT |
| Website changes | **Fully integrated & verified** (`/api/scan-food`, `/api/scan-food/search`, `scanner/page.tsx`, Next.js 16 build passed) |

## Test results (actually executed)
- `python -m pytest -q`: **36 passed, 0 failed** in 4.93s across all unit and API test suites.
- Live OpenCLIP zero-shot inference tests:
  - Apple image: `accepted` (gate: 99.68% food, top candidate: Apple `f-apple-fresh` with 99.78% prob).
  - Laptop / non-food object: `rejected_non_food` (gate: 99.99% non-food).
  - Ambiguous / drawn shapes: `ambiguous` (no forced dish).
  - Non-image data: HTTP 422 `not_an_image` / `invalid_image`.
  - Nutrition calculation: `f-apple-fresh` 182g returns 95.0 kcal with accurate Atwater macros.

## Architecture
`scanner/pipeline.py:ScannerService` → `image_quality` → `classifier/{onnx_backend|clip_backend}` → `classifier/decision` → `nutrition/{matching,calculator,units}` over `data/reference_foods.json`. API in `scanner/api/app.py`. Taxonomy `configs/taxonomy.json` (43 classes → DB ids). Details: `ANTIGRAVITY_INTEGRATION_GUIDE.md`.

## Key decisions (don't undo)
1. Gate and ID are separate models. 2. No fallback food; null nutrient = unavailable. 3. Photos never determine portion. 4. Classification probability ≠ nutrition accuracy (never merged). 5. Reported kcal preserved; Atwater is a flag. 6. No model files may be created unless produced by real training/export.

## Limitations
No trained model; uncalibrated thresholds; 43 classes; single-label per image; no multi-item plate parsing; no OCR/barcode; composite recipes generic; unverified nutrient source; ml→g assumes 1 g/ml unless flagged; blur/brightness thresholds are untuned heuristics.

## Prioritised remaining work
1. Assemble data (incl. hard negatives), train gate + ID, export, evaluate on held-out test, calibrate thresholds, set `SCANNER_THRESHOLDS_CALIBRATED=true`. 2. Install deps and run API tests; fix any FastAPI issues. 3. Verify/replace nutrition values via USDA FDC / IFCT; add food densities. 4. Apply website changes (guide §6), run `npm run build`. 5. Multi-item detection, label OCR/barcode. 6. Rotate the possibly-real key fragment; remove SSRF path.

## Continuation prompt for another AI
```
Resume work on nutritrack-scanner/. Read SCANNER_AI_CONTEXT.md, AUDIT_REPORT.md, MODEL_TRAINING_REPORT.md first. Do not undo: separate gate/ID models, null-means-unavailable nutrition, no default/fallback foods, user-confirmed portions, honest statuses. Do not create fake weights or invent metrics. First run `python -m unittest discover -s tests -t .` (expect 31 pass, 5 skipped without fastapi). Then, depending on environment: (a) if network+GPU exist, follow training/DATASETS.md and MODEL_TRAINING_REPORT.md "Reproduce", record REAL metrics there and in SCANNER_CHANGELOG.md; (b) install requirements.txt and run the API tests; (c) apply the website integration in ANTIGRAVITY_INTEGRATION_GUIDE.md §6/§9. Update all five docs when behaviour changes and mark each item implemented-verified / unverified / planned.
```

"""NutriTrack scanner: image validation -> food gate -> food ID -> nutrition lookup."""
__version__ = "0.1.0"

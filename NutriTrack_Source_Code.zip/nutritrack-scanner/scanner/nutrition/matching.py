"""Text -> database entry. Never falls back to an arbitrary entry (the legacy engine used DB[0])."""
import difflib, re
from typing import Dict, List
from .database import ReferenceDB


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", s.lower().replace("_", " ")).strip()


def search(db: ReferenceDB, query: str, limit: int = 5, min_score: float = 0.45) -> List[Dict]:
    """Ranked candidates [{id,name,score}] - used for the manual-correction search box."""
    q = _norm(query)
    if len(q) < 2:
        return []
    qt = set(q.split())
    out = []
    for f in db.foods:
        name = _norm(f["name"])
        nt = set(name.split())
        token = len(qt & nt) / max(len(qt), 1)
        seq = difflib.SequenceMatcher(None, q, name).ratio()
        contains = 1.0 if q in name else 0.0
        score = max(contains * 0.95, 0.6 * token + 0.4 * seq)
        if score >= min_score:
            out.append({"id": f["id"], "name": f["name"], "score": round(score, 3), "kind": f["kind"]})
    out.sort(key=lambda r: -r["score"])
    return out[:limit]

"""Reference nutrition database loader (JSON). Source-agnostic: legacy seed, USDA import, etc."""
import json
from pathlib import Path
from typing import Dict, List, Optional

NUTRIENT_KEYS = ["calories", "protein", "carbs", "fats", "fiber", "sugar", "sodium",
                 "potassium", "calcium", "iron", "vitaminA", "vitaminC"]
UNITS = {"calories": "kcal", "protein": "g", "carbs": "g", "fats": "g", "fiber": "g", "sugar": "g",
         "sodium": "mg", "potassium": "mg", "calcium": "mg", "iron": "mg", "vitaminA": "mcg", "vitaminC": "mg"}


class ReferenceDB:
    def __init__(self, path: Path):
        raw = json.loads(Path(path).read_text())
        self.source_note = raw.get("source_note", "")
        self.foods: List[Dict] = raw["foods"]
        self._by_id = {f["id"]: f for f in self.foods}

    def get(self, food_id: str) -> Optional[Dict]:
        return self._by_id.get(food_id)

    def __len__(self):
        return len(self.foods)

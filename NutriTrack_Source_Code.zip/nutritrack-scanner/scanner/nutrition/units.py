"""Unit conversion to grams. Volume->mass requires a density; when unknown we say so."""
from dataclasses import dataclass
from typing import Optional

MASS_G = {"g": 1.0, "gram": 1.0, "grams": 1.0, "kg": 1000.0, "mg": 0.001, "oz": 28.349523125, "lb": 453.59237}
VOLUME_ML = {"ml": 1.0, "l": 1000.0, "tsp": 4.92892159375, "tbsp": 14.78676478125,
             "cup": 240.0, "fl_oz": 29.5735295625}  # US customary; metric cup (250 ml) must be sent as ml


class UnitError(ValueError):
    pass


@dataclass
class GramsResult:
    grams: float
    assumed_density: bool = False  # True if a volume was converted with the 1.0 g/ml default


def to_grams(amount: float, unit: str, density_g_per_ml: Optional[float] = None) -> GramsResult:
    if amount is None or amount != amount or amount <= 0:
        raise UnitError("Amount must be a positive number.")
    if amount > 50_000:
        raise UnitError("Amount is unrealistically large.")
    u = (unit or "").strip().lower()
    if u in MASS_G:
        return GramsResult(amount * MASS_G[u])
    if u in VOLUME_ML:
        ml = amount * VOLUME_ML[u]
        if density_g_per_ml:
            return GramsResult(ml * density_g_per_ml)
        return GramsResult(ml * 1.0, assumed_density=True)
    raise UnitError(f"Unsupported unit '{unit}'. Use g, kg, mg, oz, lb, ml, l, tsp, tbsp, cup, fl_oz, or a serving count.")

"""Nutrient calculation. Missing nutrients stay None; nothing is defaulted or invented."""
from typing import Dict, List, Optional
from .database import NUTRIENT_KEYS, UNITS, ReferenceDB
from .units import to_grams, UnitError

ATWATER_TOL_REL = 0.15
ATWATER_TOL_ABS = 10.0


def _r(v: Optional[float], nd: int = 1) -> Optional[float]:
    return None if v is None else round(v, nd)


def serving_options(food: Dict) -> List[Dict]:
    """Portion choices offered to the user. Only weights actually present in the data."""
    opts = [{"label": "100 g", "grams": 100.0}]
    s = food.get("serving", {})
    if s.get("grams"):
        opts.insert(0, {"label": s["label"], "grams": float(s["grams"]),
                        "weight_basis": s.get("weight_basis")})
    return opts


def compute_item(food: Dict, grams: float, assumed_density: bool = False) -> Dict:
    per100 = food["per_100g"]
    f = grams / 100.0
    nutrients = {k: (None if per100.get(k) is None else per100[k] * f) for k in NUTRIENT_KEYS}
    rounded = {k: (_r(v, 0) if k in ("calories", "sodium", "potassium", "calcium") else _r(v, 1)) for k, v in nutrients.items()}
    flags = []
    if per100.get("calories") is not None and all(per100.get(k) is not None for k in ("protein", "carbs", "fats")):
        atw = 4 * nutrients["protein"] + 4 * nutrients["carbs"] + 9 * nutrients["fats"]
        diff = abs(atw - nutrients["calories"])
        if diff > max(ATWATER_TOL_ABS, ATWATER_TOL_REL * nutrients["calories"]):
            flags.append("atwater_mismatch")
    if assumed_density:
        flags.append("volume_converted_with_assumed_density_1g_per_ml")
    if not food.get("source_verified", False):
        flags.append("reference_values_not_independently_verified")
    if food.get("serving", {}).get("weight_basis", "").endswith("UNVERIFIED"):
        flags.append("serving_weight_unverified")
    if food.get("kind") == "composite_recipe":
        flags.append("composite_recipe_values_vary_by_recipe")
    return {
        "food_id": food["id"], "name": food["name"], "grams": _r(grams, 1),
        "nutrients": {k: {"value": rounded[k], "unit": UNITS[k], "available": rounded[k] is not None} for k in NUTRIENT_KEYS},
        "reference_type": food["kind"],        # generic_reference | composite_recipe (never product-specific here)
        "source": food["source"], "source_verified": food.get("source_verified", False),
        "flags": flags,
    }


def compute(db: ReferenceDB, food_id: str, amount: float, unit: str = "g", servings: Optional[float] = None) -> Dict:
    """amount+unit in mass/volume, OR servings=N meaning N * the entry's reference serving."""
    food = db.get(food_id)
    if food is None:
        raise KeyError(food_id)
    if servings is not None:
        sg = food.get("serving", {}).get("grams")
        if not sg:
            raise UnitError("This food has no defined serving weight; enter grams instead.")
        if servings <= 0 or servings > 100:
            raise UnitError("Servings must be between 0 and 100.")
        return compute_item(food, sg * servings)
    g = to_grams(amount, unit)  # no per-food density data yet -> volume conversions are flagged as assumed
    return compute_item(food, g.grams, assumed_density=g.assumed_density)


def total(items: List[Dict]) -> Dict:
    """Sum across items. A nutrient total is only complete if every item has it."""
    out = {}
    for k in NUTRIENT_KEYS:
        vals = [it["nutrients"][k]["value"] for it in items]
        known = [v for v in vals if v is not None]
        out[k] = {"value": _r(sum(known), 1) if known else None, "unit": UNITS[k],
                  "complete": len(known) == len(vals) and len(vals) > 0,
                  "items_missing": len(vals) - len(known)}
    return out

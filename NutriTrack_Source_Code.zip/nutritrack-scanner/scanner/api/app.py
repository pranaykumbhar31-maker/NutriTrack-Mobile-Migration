"""FastAPI service. Run:  uvicorn scanner.api.app:app --host 0.0.0.0 --port 8001
NOTE: written but NOT executed in the authoring sandbox (fastapi not installable offline). See SCANNER_AI_CONTEXT.md."""
import hmac, logging
from typing import List, Optional

from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, model_validator

from ..config import get_settings
from ..pipeline import ScannerService

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
settings = get_settings()
service = ScannerService(settings)
app = FastAPI(title="NutriTrack Scanner", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=list(settings.cors_origins), allow_methods=["GET", "POST"], allow_headers=["*"])


def require_key(x_api_key: Optional[str] = Header(default=None)):
    if settings.api_key and not hmac.compare_digest(x_api_key or "", settings.api_key):
        raise HTTPException(401, "Invalid or missing API key.")


class NutritionItem(BaseModel):
    food_id: str = Field(min_length=1, max_length=100)
    grams: Optional[float] = Field(default=None, gt=0, le=50000)
    amount: Optional[float] = Field(default=None, gt=0, le=50000)
    unit: Optional[str] = Field(default="g", max_length=10)
    servings: Optional[float] = Field(default=None, gt=0, le=100)

    @model_validator(mode="after")
    def one_quantity(self):
        if self.grams is None and self.amount is None and self.servings is None:
            raise ValueError("Provide grams, amount+unit, or servings.")
        return self


class NutritionRequest(BaseModel):
    items: List[NutritionItem] = Field(min_length=1, max_length=30)


@app.get("/health")
def health():
    return service.health()


@app.post("/predict", dependencies=[Depends(require_key)])
async def predict(image: UploadFile = File(...)):
    data = await image.read(settings.max_upload_bytes + 1)  # bounded read
    res = service.predict(data)
    if res["status"] == "invalid_image":
        raise HTTPException(422, {"error_code": res["error_code"], "message": res["message"]})
    return res


@app.post("/nutrition", dependencies=[Depends(require_key)])
def nutrition(req: NutritionRequest):
    out = service.nutrition([i.model_dump(exclude_none=True) for i in req.items])
    if not out["items"]:
        raise HTTPException(422, out["errors"])
    return out


@app.get("/foods/search", dependencies=[Depends(require_key)])
def foods_search(q: str, limit: int = 8):
    return {"results": service.search_foods(q[:80], min(limit, 20))}


@app.get("/foods/{food_id}/servings", dependencies=[Depends(require_key)])
def servings(food_id: str):
    opts = service.serving_options(food_id)
    if opts is None:
        raise HTTPException(404, "Unknown food_id.")
    return {"food_id": food_id, "options": opts}

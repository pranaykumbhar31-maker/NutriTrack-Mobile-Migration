"""Safe image decoding + quality checks. Pure PIL/numpy/OpenCV; no model needed."""
from dataclasses import dataclass, field
from io import BytesIO
from typing import List, Optional
import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

from .config import Settings

ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}


class ImageRejected(Exception):
    """Raised for unreadable / unsafe images. `code` is machine-readable."""
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code, self.message = code, message


@dataclass
class QualityReport:
    width: int
    height: int
    blur_score: float
    brightness: float
    issues: List[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.issues

    def to_dict(self):
        return {"width": self.width, "height": self.height, "blur_score": round(self.blur_score, 1),
                "brightness": round(self.brightness, 1), "issues": self.issues}


def decode_image(data: bytes, settings: Settings) -> Image.Image:
    if not data:
        raise ImageRejected("empty_upload", "No image data received.")
    if len(data) > settings.max_upload_bytes:
        raise ImageRejected("too_large", f"Image exceeds {settings.max_upload_bytes // (1024*1024)} MB limit.")
    try:
        probe = Image.open(BytesIO(data))
        fmt = probe.format
        w, h = probe.size
    except (UnidentifiedImageError, OSError, ValueError):
        raise ImageRejected("not_an_image", "File is not a readable JPEG, PNG or WebP image.")
    if fmt not in ALLOWED_FORMATS:
        raise ImageRejected("unsupported_format", f"Unsupported image format: {fmt}. Use JPEG, PNG or WebP.")
    if w * h > settings.max_pixels:  # decompression-bomb guard before full decode
        raise ImageRejected("too_many_pixels", "Image resolution is too large.")
    try:
        img = Image.open(BytesIO(data))
        img = ImageOps.exif_transpose(img)  # honour phone camera orientation
        return img.convert("RGB")
    except Exception:
        raise ImageRejected("decode_failed", "Image appears corrupted and could not be decoded.")


def assess_quality(img: Image.Image, settings: Settings) -> QualityReport:
    import cv2
    w, h = img.size
    issues: List[str] = []
    arr = np.asarray(img)
    gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)
    # normalise scale so blur score does not depend on resolution
    scale = 512.0 / max(gray.shape)
    if scale < 1.0:
        gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    blur = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    bright = float(gray.mean())
    if min(w, h) < settings.min_side_px:
        issues.append("too_small")
    if blur < settings.blur_laplacian_min:
        issues.append("blurry")
    if bright < settings.brightness_min:
        issues.append("too_dark")
    elif bright > settings.brightness_max:
        issues.append("too_bright")
    return QualityReport(w, h, blur, bright, issues)

"""ScannerService: the framework-independent entry point (usable without the web API)."""
import json, logging, time
from pathlib import Path
from typing import Dict, Optional

from .config import Settings, get_settings
from .image_quality import ImageRejected, assess_quality, decode_image
from .classifier.base import BackendUnavailable, ClassifierBackend
from .classifier import decision as D
from .nutrition.database import ReferenceDB
from .nutrition import calculator, matching
from .nutrition.units import UnitError

log = logging.getLogger("nutritrack.scanner")


class ScannerService:
    def __init__(self, settings: Optional[Settings] = None, backend: Optional[ClassifierBackend] = None,
                 db: Optional[ReferenceDB] = None):
        self.s = settings or get_settings()
        self.db = db or ReferenceDB(self.s.reference_db_path)
        tax = json.loads(Path(self.s.taxonomy_path).read_text())
        self.taxonomy = {c["label"]: c for c in tax["classes"]}
        self.backend = backend
        self.backend_error: Optional[str] = None
        if self.backend is None:
            self._load_backend()

    def _load_backend(self):
        try:
            if self.s.backend == "clip_zero_shot":
                from .classifier.clip_backend import ClipBackend
                self.backend = ClipBackend(self.s.taxonomy_path)
            else:
                from .classifier.onnx_backend import OnnxBackend
                self.backend = OnnxBackend(self.s.gate_model_dir, self.s.id_model_dir)
        except BackendUnavailable as e:
            self.backend, self.backend_error = None, str(e)
            log.warning("classifier backend unavailable: %s", e)

    # ------------------------------------------------------------------ health
    def health(self) -> Dict:
        return {"status": "ok" if self.backend else "degraded",
                "model_loaded": self.backend is not None,
                "model_error": self.backend_error,
                "reference_foods": len(self.db),
                "thresholds_calibrated": self.s.thresholds_calibrated,
                "nutrition_source_verified": False}

    # ----------------------------------------------------------------- predict
    def predict(self, image_bytes: bytes) -> Dict:
        t0 = time.time()
        try:
            img = decode_image(image_bytes, self.s)
        except ImageRejected as e:
            return {"status": "invalid_image", "error_code": e.code, "message": e.message}
        quality = assess_quality(img, self.s)
        base = {"quality": quality.to_dict(), "thresholds_calibrated": self.s.thresholds_calibrated}
        if "too_small" in quality.issues or "blurry" in quality.issues or "too_dark" in quality.issues or "too_bright" in quality.issues:
            msgs = {"too_small": "image is too small", "blurry": "image is blurry", "too_dark": "image is too dark", "too_bright": "image is overexposed"}
            return {**base, "status": D.LOW_QUALITY,
                    "message": "Please retake the photo: " + ", ".join(msgs[i] for i in quality.issues) + "."}
        if self.backend is None:
            return {**base, "status": D.MODEL_UNAVAILABLE,
                    "message": "The food recognition model is not available. You can still search for a food manually."}
        try:
            gate = self.backend.predict_gate(img)
            term = D.decide_gate(gate.probs, self.s)
            if term:
                return {**base, "status": term.status, "message": term.message, "gate": gate.probs, "candidates": [],
                        "model_id": gate.model_id, "latency_ms": int((time.time() - t0) * 1000)}
            ident = self.backend.predict_id(img)
        except Exception:  # model runtime failure must never leak internals
            log.exception("inference failure")
            return {**base, "status": D.MODEL_UNAVAILABLE, "message": "Recognition failed. Please try again or search manually."}
        dec = D.decide_id(ident.candidates, gate.probs, self.s)
        cands = []
        for c in dec.candidates:
            tax = self.taxonomy.get(c["label"])
            cands.append({"label": c["label"], "display": tax["display"] if tax else c["label"],
                          "food_id": tax["db_id"] if tax else None, "match_quality": tax["match_quality"] if tax else None,
                          "probability": round(c["prob"], 4)})
        return {**base, "status": dec.status, "message": dec.message, "gate": gate.probs, "candidates": cands,
                "model_id": ident.model_id,
                "classification_confidence_note": "Probability reflects image-model certainty about the food label. It says nothing about nutrient accuracy.",
                "portion": {"status": "needs_user_input",
                            "message": "Portion size cannot be measured from a photo. Choose a serving or enter grams."},
                "latency_ms": int((time.time() - t0) * 1000)}

    # --------------------------------------------------------------- nutrition
    def nutrition(self, items: list) -> Dict:
        """items: [{food_id, grams? | amount+unit? | servings?}]"""
        results, errors = [], []
        for i, it in enumerate(items):
            try:
                fid = it["food_id"]
                if it.get("servings") is not None:
                    r = calculator.compute(self.db, fid, 0, servings=float(it["servings"]))
                elif it.get("grams") is not None:
                    r = calculator.compute(self.db, fid, float(it["grams"]), "g")
                else:
                    r = calculator.compute(self.db, fid, float(it["amount"]), it.get("unit", "g"))
                results.append(r)
            except KeyError:
                errors.append({"index": i, "code": "unknown_food_id", "message": f"Unknown food_id '{it.get('food_id')}'."})
            except (UnitError, ValueError, TypeError) as e:
                errors.append({"index": i, "code": "invalid_quantity", "message": str(e)})
        out = {"items": results, "errors": errors}
        if results:
            out["total"] = calculator.total(results)
        out["disclaimer"] = "Values are generic reference data for the selected food and amount, not a measurement of the photographed serving."
        return out

    def search_foods(self, q: str, limit: int = 8):
        return matching.search(self.db, q, limit)

    def serving_options(self, food_id: str):
        f = self.db.get(food_id)
        return None if f is None else calculator.serving_options(f)

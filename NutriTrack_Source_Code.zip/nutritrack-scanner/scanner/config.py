"""Runtime configuration (environment variables). No secrets are logged or returned."""
from dataclasses import dataclass, field
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _f(name, default):
    return float(os.environ.get(name, default))


@dataclass(frozen=True)
class Settings:
    # --- upload limits ---
    max_upload_bytes: int = int(os.environ.get("SCANNER_MAX_UPLOAD_BYTES", 8 * 1024 * 1024))
    max_pixels: int = int(os.environ.get("SCANNER_MAX_PIXELS", 40_000_000))
    min_side_px: int = int(os.environ.get("SCANNER_MIN_SIDE_PX", 128))
    # --- image-quality gates (heuristics; tune on real photos) ---
    blur_laplacian_min: float = _f("SCANNER_BLUR_MIN", 40.0)
    brightness_min: float = _f("SCANNER_BRIGHTNESS_MIN", 35.0)
    brightness_max: float = _f("SCANNER_BRIGHTNESS_MAX", 235.0)
    # --- decision thresholds ---
    # PLACEHOLDER VALUES. Not calibrated: no validation data has been run (see MODEL_TRAINING_REPORT.md).
    # Calibrate with training/evaluate.py --calibrate and set via env / configs/thresholds.json.
    gate_food_accept: float = _f("SCANNER_GATE_FOOD_ACCEPT", 0.80)
    gate_nonfood_reject: float = _f("SCANNER_GATE_NONFOOD_REJECT", 0.80)
    id_accept: float = _f("SCANNER_ID_ACCEPT", 0.60)
    thresholds_calibrated: bool = os.environ.get("SCANNER_THRESHOLDS_CALIBRATED", "false").lower() == "true"
    # --- model + data locations ---
    gate_model_dir: Path = Path(os.environ.get("SCANNER_GATE_MODEL_DIR", ROOT / "models" / "food_gate"))
    id_model_dir: Path = Path(os.environ.get("SCANNER_ID_MODEL_DIR", ROOT / "models" / "food_classifier"))
    reference_db_path: Path = Path(os.environ.get("SCANNER_REFERENCE_DB", ROOT / "data" / "reference_foods.json"))
    taxonomy_path: Path = Path(os.environ.get("SCANNER_TAXONOMY", ROOT / "configs" / "taxonomy.json"))
    backend: str = os.environ.get("SCANNER_BACKEND", "onnx")  # onnx | clip_zero_shot
    cors_origins: tuple = tuple(o for o in os.environ.get("SCANNER_CORS_ORIGINS", "http://localhost:3000").split(",") if o)
    api_key: str = os.environ.get("SCANNER_API_KEY", "")  # optional shared secret (never echoed)


def get_settings() -> Settings:
    return Settings()

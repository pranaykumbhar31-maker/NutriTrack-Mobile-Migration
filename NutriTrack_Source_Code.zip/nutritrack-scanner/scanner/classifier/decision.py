"""Turns raw model probabilities into a safe product decision. No nutrition logic here."""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from ..config import Settings

# status values (stable API contract)
ACCEPTED = "accepted"                    # food + confident ID
NEEDS_CONFIRMATION = "needs_confirmation"  # food, but ID not confident: user picks from candidates
REJECTED_NON_FOOD = "rejected_non_food"
AMBIGUOUS = "ambiguous"                  # cannot tell food from non-food (mixed scene, odd image)
PACKAGED_LABEL = "packaged_label_detected"  # nutrition label: manual entry (OCR not implemented)
LOW_QUALITY = "low_quality_image"
MODEL_UNAVAILABLE = "model_unavailable"


@dataclass
class Decision:
    status: str
    message: str
    gate_probs: Dict[str, float] = field(default_factory=dict)
    candidates: List[Dict] = field(default_factory=list)
    top_label: Optional[str] = None
    top_prob: Optional[float] = None


def decide_gate(gate_probs: Dict[str, float], s: Settings) -> Optional[Decision]:
    """Return a terminal Decision if the image should NOT proceed to food ID, else None."""
    food = gate_probs.get("food", 0.0)
    non_food = gate_probs.get("non_food", 0.0)
    label = gate_probs.get("nutrition_label", 0.0)
    if label >= s.gate_food_accept:
        return Decision(PACKAGED_LABEL, "A nutrition label was detected. Label reading is not available yet; please enter the values manually.", gate_probs)
    if non_food >= s.gate_nonfood_reject:
        return Decision(REJECTED_NON_FOOD, "This doesn't look like food. Please photograph an edible meal, ingredient or drink.", gate_probs)
    if food < s.gate_food_accept:
        return Decision(AMBIGUOUS, "We couldn't tell whether this image shows food. Try a clearer, closer photo of just the food, or enter it manually.", gate_probs)
    return None


def decide_id(candidates: List[Dict], gate_probs: Dict[str, float], s: Settings) -> Decision:
    top = candidates[0] if candidates else None
    if top is None:
        return Decision(NEEDS_CONFIRMATION, "Food could not be identified. Please search for it manually.", gate_probs, [])
    if top["prob"] >= s.id_accept:
        return Decision(ACCEPTED, "Food identified.", gate_probs, candidates, top["label"], top["prob"])
    return Decision(NEEDS_CONFIRMATION, "We're not sure what this is. Please pick the closest match or search manually.",
                    gate_probs, candidates, top["label"], top["prob"])

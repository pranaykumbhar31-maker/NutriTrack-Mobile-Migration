"""Backend interface. Gate (food / non-food / label) and ID (which food) are separate models."""
from dataclasses import dataclass
from typing import Dict, List, Protocol
from PIL import Image


@dataclass
class GateResult:
    probs: Dict[str, float]          # keys: food, non_food, nutrition_label (optional)
    model_id: str


@dataclass
class IdResult:
    candidates: List[Dict]           # [{"label": str, "prob": float}, ...] sorted desc
    model_id: str


class ClassifierBackend(Protocol):
    def predict_gate(self, img: Image.Image) -> GateResult: ...
    def predict_id(self, img: Image.Image, top_k: int = 5) -> IdResult: ...


class BackendUnavailable(RuntimeError):
    """Model files missing / runtime not installed. The API maps this to HTTP 503."""

"""ONNX Runtime backend for models exported by training/export_onnx.py.

Expected files in each model dir:  model.onnx, labels.json, model_config.json
model_config.json: {"input_size":224,"mean":[..],"std":[..],"model_id":"...","version":"..."}
labels.json: ["class0","class1",...]   (index == logit index)
Nothing is shipped in models/ by default: until you train/export, the service reports 'model_unavailable'.
"""
import json
from pathlib import Path
from typing import List
import numpy as np
from PIL import Image
from .base import BackendUnavailable, GateResult, IdResult


def _softmax(x: np.ndarray) -> np.ndarray:
    e = np.exp(x - x.max())
    return e / e.sum()


class _OnnxModel:
    def __init__(self, model_dir: Path):
        model_dir = Path(model_dir)
        need = [model_dir / n for n in ("model.onnx", "labels.json", "model_config.json")]
        missing = [p.name for p in need if not p.exists()]
        if missing:
            raise BackendUnavailable(f"{model_dir.name}: missing {missing}")
        import onnxruntime as ort
        self.sess = ort.InferenceSession(str(model_dir / "model.onnx"), providers=["CPUExecutionProvider"])
        self.labels: List[str] = json.loads((model_dir / "labels.json").read_text())
        self.cfg = json.loads((model_dir / "model_config.json").read_text())
        self.input_name = self.sess.get_inputs()[0].name
        n_out = self.sess.get_outputs()[0].shape[-1]
        if isinstance(n_out, int) and n_out != len(self.labels):
            raise BackendUnavailable(f"{model_dir.name}: labels ({len(self.labels)}) != model outputs ({n_out})")

    def probs(self, img: Image.Image) -> np.ndarray:
        s = int(self.cfg["input_size"])
        im = img.resize((s, s), Image.BICUBIC)  # must mirror training/eval transforms
        a = (np.asarray(im, dtype=np.float32) / 255.0 - np.array(self.cfg["mean"], np.float32)) / np.array(self.cfg["std"], np.float32)
        a = a.transpose(2, 0, 1)[None].astype(np.float32)
        logits = self.sess.run(None, {self.input_name: a})[0][0]
        return _softmax(logits.astype(np.float64))


class OnnxBackend:
    def __init__(self, gate_dir: Path, id_dir: Path):
        self.gate = _OnnxModel(gate_dir)
        self.id = _OnnxModel(id_dir)

    def predict_gate(self, img):
        p = self.gate.probs(img)
        return GateResult({l: float(v) for l, v in zip(self.gate.labels, p)}, self.gate.cfg.get("model_id", "onnx-gate"))

    def predict_id(self, img, top_k=5):
        p = self.id.probs(img)
        idx = np.argsort(-p)[:top_k]
        return IdResult([{"label": self.id.labels[i], "prob": float(p[i])} for i in idx], self.id.cfg.get("model_id", "onnx-id"))

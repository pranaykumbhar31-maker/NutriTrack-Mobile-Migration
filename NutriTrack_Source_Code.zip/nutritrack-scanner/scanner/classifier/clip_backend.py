"""Optional zero-shot backend (no training) using OpenCLIP. UNVERIFIED in this repo's sandbox:
needs `pip install open_clip_torch torch` and a network download of weights on first run.

Default weights: ViT-B-32 / laion2b_s34b_b79k (OpenCLIP, MIT code; LAION-2B weights).
Check the weight licence/terms for your deployment before shipping.
Zero-shot accuracy on your own label set is UNKNOWN until you run training/evaluate.py with --backend clip_zero_shot.
"""
import json
from pathlib import Path
from typing import List
from .base import BackendUnavailable, GateResult, IdResult

GATE_PROMPTS = {
    "food": ["a photo of food", "a photo of a cooked meal on a plate", "a photo of fruit or vegetables", "a photo of a drink"],
    "non_food": ["a photo of a household object", "a photo of soap or a cleaning product", "a photo of stationery or a pen",
                 "a photo of medicine packaging", "a photo of an electronic device", "a photo of a person", "a photo of plastic"],
    "nutrition_label": ["a photo of a nutrition facts label", "a photo of packaged food ingredients list"],
}


class ClipBackend:
    def __init__(self, taxonomy_path: Path, model="ViT-B-32", pretrained="laion2b_s34b_b79k"):
        try:
            import torch, open_clip  # noqa
        except Exception as e:
            raise BackendUnavailable(f"open_clip/torch not installed: {e}")
        self.torch = torch
        self.model, _, self.preprocess = open_clip.create_model_and_transforms(model, pretrained=pretrained)
        self.tok = open_clip.get_tokenizer(model)
        self.model.eval()
        tax = json.loads(Path(taxonomy_path).read_text())
        self.labels: List[str] = [c["label"] for c in tax["classes"]]
        self._id_text = self._enc([f"a photo of {c['display'].lower()}, a type of food" for c in tax["classes"]])
        self._gate_text = {k: self._enc(v) for k, v in GATE_PROMPTS.items()}
        self.model_id = f"openclip:{model}:{pretrained}"

    def _enc(self, texts):
        with self.torch.no_grad():
            t = self.model.encode_text(self.tok(texts))
            return t / t.norm(dim=-1, keepdim=True)

    def _img(self, img):
        with self.torch.no_grad():
            f = self.model.encode_image(self.preprocess(img).unsqueeze(0))
            return f / f.norm(dim=-1, keepdim=True)

    def predict_gate(self, img):
        f = self._img(img)
        scores = {k: (100.0 * f @ v.T).max().item() for k, v in self._gate_text.items()}
        vals = self.torch.tensor(list(scores.values())).softmax(0).tolist()
        return GateResult(dict(zip(scores.keys(), vals)), self.model_id)

    def predict_id(self, img, top_k=5):
        f = self._img(img)
        p = (100.0 * f @ self._id_text.T).softmax(-1)[0]
        v, i = p.topk(min(top_k, len(self.labels)))
        return IdResult([{"label": self.labels[j], "prob": float(x)} for x, j in zip(v.tolist(), i.tolist())], self.model_id)

# Antigravity integration guide

> Status legend: **[ran]** executed in the authoring sandbox · **[unrun]** written but never executed · **[none]** does not exist yet.

## 1. Architecture
```
Browser (scanner/page.tsx) --imageBase64--> Next.js /api/scan-food  (server-side proxy, holds SCANNER_API_KEY)
                                              |--multipart--> Python scanner  POST /predict   (gate -> ID -> decision)
                                              |--json-------> Python scanner  POST /nutrition (reference-DB lookup)
```
Why a separate Python service: image models run on ONNX Runtime/PyTorch and weights are large; Vercel serverless is a poor fit. The browser never talks to the scanner directly (keeps the key and CORS surface small).
Pipeline in the service: decode+validate → quality gate → **gate model** (food / non_food / nutrition_label) → **ID model** (43 classes) → decision (accepted / needs_confirmation / rejected_non_food / ambiguous / low_quality_image / packaged_label_detected / model_unavailable) → user confirms portion → `/nutrition`.

## 2. Directory
```
nutritrack-scanner/
  scanner/           config.py image_quality.py pipeline.py  classifier/{base,onnx_backend,clip_backend,decision}.py  nutrition/{units,database,matching,calculator}.py  api/app.py
  data/reference_foods.json      46 foods, per-100 g, provenance flags (legacy seed, NOT verified)
  configs/                       taxonomy.json  train_gate.yaml  train_id.yaml
  training/ tools/ tests/ models/ integration/
  integration/scan-food.route.proposed.ts   drop-in replacement for the website's src/app/api/scan-food/route.ts
```

## 3. Runtime & install  
Python 3.10+ (developed on 3.12). `pip install -r requirements.txt`. Env vars: see `.env.example` (`SCANNER_API_KEY`, `SCANNER_CORS_ORIGINS`, `SCANNER_BACKEND`, thresholds).
Website env (server-only, Vercel project settings): `SCANNER_URL`, `SCANNER_API_KEY`.

## 4. Start & test
```bash
cd nutritrack-scanner
python -m unittest discover -s tests -t . -v         # [ran] 36 collected: 31 pass, 5 API tests skipped (fastapi not installable offline)
pip install -r requirements.txt && python -m pytest -q # [unrun] includes API tests
uvicorn scanner.api.app:app --port 8001                # [unrun]
curl localhost:8001/health                             # {"status":"degraded","model_loaded":false,...} until a model is trained
curl -X POST localhost:8001/nutrition -H 'content-type: application/json' -d '{"items":[{"food_id":"f-apple-fresh","grams":182}]}'
curl -X POST localhost:8001/predict -F image=@photo.jpg
```
**Model loading:** at startup `ScannerService` loads `models/food_gate/` and `models/food_classifier/` (ONNX). Missing files → `model_unavailable`, never fake output. **No model is included**; you must train (see `MODEL_TRAINING_REPORT.md`) or set `SCANNER_BACKEND=clip_zero_shot` (needs `pip install open_clip_torch torch`, network, **[unrun]**).

## 5. API contract
`GET /health`, `POST /predict` (multipart field `image`, ≤8 MB; JPEG/PNG/WebP), `POST /nutrition`, `GET /foods/search?q=`, `GET /foods/{id}/servings`. Optional header `X-API-Key`.
`/predict` → `{status, message, candidates:[{label,display,food_id,match_quality,probability}], gate:{food,non_food,nutrition_label}, quality:{...}, portion:{status:"needs_user_input"}}`. 422 for unreadable images.
`/nutrition` request: `{"items":[{"food_id":"f-apple-fresh","grams":182}]}` (or `amount`+`unit`, or `servings`). Response nutrients are `{value|null, unit, available}`; `flags[]` (e.g. `reference_values_not_independently_verified`, `composite_recipe_values_vary_by_recipe`); totals carry `complete:false` if any item lacks a nutrient.
`probability` is **classification confidence only**; it is not nutrient accuracy.

## 6. Frontend changes needed (website, minimal)
1. Replace `src/app/api/scan-food/route.ts` with `integration/scan-food.route.proposed.ts` (keeps the response fields the page already reads, adds `scanStatus`, `candidates`, `needsConfirmation`, `portionRequired`). Remove `customApiKey`, `fileName`, `userDescription` hint use, `clientFeatures`, and the Groq/Gemini key UI block (`scanner/page.tsx` ~L1000-1015).
2. In `scanner/page.tsx`: delete `extractClientImageFeatures`; on `scanStatus === 'needs_confirmation'` show `candidates` as chips plus a text search (`GET /foods/search` via a small Next route); always show a **grams / serving selector** (options from `/foods/{id}/servings`) and re-call the route with `{foodId, grams}` on change.
3. Replace `it.nutrition.fiber || 2` and `it.confidence || 0.95` with "n/a"/hidden when `undefined`. Do not show vitamins/minerals unless `available`.
4. Show non-accept statuses (`rejected_non_food`, `ambiguous`, `low_quality_image`, `packaged_label_detected`, `model_unavailable`) using `rejectionReason`, with a "search manually" button.
5. Leave auth, Supabase/LocalStorage sync, routes, styling untouched. Saved meal logs keep the existing `MealLog` shape; **no DB migration** is required.

## 7. Deployment & security
Run the scanner as a container/VM (Render, Fly, Railway, Cloud Run, or any VPS); set `SCANNER_CORS_ORIGINS` to your site; set a long random `SCANNER_API_KEY`; call it only from Next server code. Put it behind HTTPS. Body limit 8 MB (configurable). Rotate the Groq key fragment noted in `AUDIT_REPORT.md` if it was real. Also remove the server-side URL-fetch (SSRF) code path when replacing the route.

## 8. Known limitations / unresolved
* **No trained model [none]**: recognition/rejection quality is unmeasured; thresholds are placeholders.
* Nutrition source is the website's legacy table (46 foods), **unverified** against USDA/IFCT; 10 composite recipes are generic. Missing nutrients stay `n/a`. USDA importer exists **[unrun]**.
* Portion size is user-confirmed, never estimated from the photo. Single dominant label only; no multi-item plate segmentation. Packaged label → manual entry (no OCR/barcode).
* FastAPI app and the proposed Next route were **not executed** here.

## 9. Copyable prompt for Antigravity
```
You are integrating a standalone food-scanner service into my existing Next.js 16 / React 19 / TypeScript site (NutriTrack AI). DO NOT rebuild the site; keep design, routes, auth, Supabase/LocalStorage sync and unrelated features.

Read first: nutritrack-scanner/ANTIGRAVITY_INTEGRATION_GUIDE.md, AUDIT_REPORT.md, integration/scan-food.route.proposed.ts.
Note: node_modules/next/dist/docs may differ from your Next.js knowledge (see AGENTS.md); check it before writing route code.

Tasks:
1. Replace src/app/api/scan-food/route.ts with the proposed proxy (adapt types/imports), reading SCANNER_URL and SCANNER_API_KEY from server env. Delete the SSRF URL-fetch path, clientFeatures trust, filename/description hint acceptance, and customApiKey relay. Remove src/lib/foodVisionEngine.ts usages from the scan route (keep the file only if other code imports it; otherwise delete).
2. Edit src/app/scanner/page.tsx: remove extractClientImageFeatures and the Groq/Gemini key UI; handle scanStatus values (accepted, needs_confirmation, rejected_non_food, ambiguous, low_quality_image, packaged_label_detected, model_unavailable); for needs_confirmation show candidate chips + manual food search; add a grams/serving selector that re-calls the route with {foodId, grams}; show "n/a" for any nutrient where value is undefined (never default fiber/sugar/sodium/confidence). Keep the existing save-to-meal-log flow.
3. Add a small route src/app/api/scan-food/search/route.ts proxying GET /foods/search and /foods/{id}/servings.
4. Add .env.example entries SCANNER_URL, SCANNER_API_KEY. Never expose them with NEXT_PUBLIC_.
5. Start the Python service (cd nutritrack-scanner; pip install -r requirements.txt; uvicorn scanner.api.app:app --port 8001) and test locally: non-image upload -> error message; /health shows model_loaded=false until weights exist (then the UI must show the manual-search fallback, not fake results); POST /nutrition for f-apple-fresh 182 g returns ~95 kcal.
6. Run `npm run build` and fix only integration-related type errors. Report what you ran and what failed. Do not claim the model is trained: it is not until models/food_gate and models/food_classifier exist.
```

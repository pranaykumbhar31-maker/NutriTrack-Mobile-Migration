# models/

**No trained model is included in this package.** Training could not be executed in the authoring environment
(no network, no GPU/torch, no datasets). Do not treat any file here as a trained model.

After you train and export (see `training/` and `MODEL_TRAINING_REPORT.md`) the expected layout is:

```
models/food_gate/        model.onnx  labels.json  model_config.json      (food | non_food | nutrition_label)
models/food_classifier/  model.onnx  labels.json  model_config.json      (labels = configs/taxonomy.json labels)
```
Until those exist the API reports `model_unavailable` and the website must fall back to manual food search.

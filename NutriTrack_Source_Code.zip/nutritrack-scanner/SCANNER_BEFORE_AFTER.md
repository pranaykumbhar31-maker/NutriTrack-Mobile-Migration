# Before / after
Legend: **V** implemented & verified (by an executed test here) · **U** implemented, unverified (code exists, not executed or no real model) · **P** planned.

| Area | Before (original site) | After (this package) | Status |
|---|---|---|---|
| Food recognition | 48×48 colour buckets → canned dish | Separate ID model interface + 43-class taxonomy; **no model trained** | **U** (pipeline V with stub; real accuracy unknown) |
| Non-food rejection | colour/entropy heuristics; bypassable via client features, filename/description hints; doc/tech checks skipped | gate model (food/non_food/label) + thresholds + `ambiguous` outcome; hints ignored | Logic **V** (stub); real FPR **unmeasured (U)** |
| Nutrition calc | DB[0] fallback; invented fiber/sugar/sodium; kcal overwritten | per-100 g scaling, nulls stay null, kcal as reported, Atwater check flag | **V** |
| Reference data | 48 rows, 2 conflicting duplicates, "USDA verified" unproven | 46 rows, provenance flags, `source_verified:false`; USDA importer | **V** (conversion) / importer **U**; verification **P** |
| Portion size | fixed hardcoded grams | user-confirmed grams/servings; options from data | Backend **V**, UI **P** |
| Vitamins/minerals | shown with defaults | shown only when present in data, else `available:false` | **V** |
| Error handling | swallowed provider errors, mixed shapes | typed statuses; model failure → `model_unavailable`, no internals leaked | **V** |
| API behaviour | single route, client-trusted | `/predict /nutrition /health /foods/*`, schemas, key, CORS, size cap | **U** (FastAPI not run) |
| Security | SSRF fetch, key relay, key fragment in code | no URL fetch, format/size/pixel caps, server-side key; site fixes still to apply | Scanner side **V/U**, website side **P** |
| UI integration | n/a | proposed route + guide | **P** |
| Performance | not measured | not measured | **P** |
| Test coverage | none found in repo | 36 collected: 31 pass, 5 skipped (API) | **V** (what ran) |

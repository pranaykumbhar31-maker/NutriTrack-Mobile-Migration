// PROPOSED replacement for src/app/api/scan-food/route.ts  (NOT applied; the website source is untouched).
// Server-side proxy to the Python scanner. Keeps the response shape the existing scanner page already reads
// (isFood, rejectionReason, plateTitle, identifiedItems[], totalEstimatedNutrition, aiObservation) and ADDS:
//   scanStatus, candidates[], needsConfirmation, portionRequired, nutritionFlags.
// NOT compiled or run against the real site in the authoring sandbox (no node_modules / no Python service reachable).
import { NextRequest, NextResponse } from 'next/server';

const SCANNER_URL = process.env.SCANNER_URL ?? 'http://localhost:8001';
const SCANNER_API_KEY = process.env.SCANNER_API_KEY ?? ''; // server-only; never NEXT_PUBLIC_

const headers = (): Record<string, string> => (SCANNER_API_KEY ? { 'X-API-Key': SCANNER_API_KEY } : {});

function dataUrlToBlob(dataUrl: string): Blob {
  const m = /^data:(image\/(?:jpeg|png|webp));base64,(.+)$/.exec(dataUrl);
  if (!m) throw new Error('bad_image_data');
  return new Blob([Buffer.from(m[2], 'base64')], { type: m[1] });
}

const NUT = ['calories', 'protein', 'carbs', 'fats', 'fiber', 'sugar', 'sodium', 'potassium', 'calcium', 'iron'] as const;

async function nutritionFor(foodId: string, grams?: number) {
  const body = grams ? { items: [{ food_id: foodId, grams }] } : { items: [{ food_id: foodId, servings: 1 }] };
  const r = await fetch(`${SCANNER_URL}/nutrition`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers() }, body: JSON.stringify(body) });
  if (!r.ok) return null;
  return (await r.json()).items?.[0] ?? null;
}

export async function POST(req: NextRequest) {
  try {
    const { imageBase64, foodId, grams } = await req.json();

    // Manual correction path: user picked a food (and maybe grams) -> recompute only.
    if (foodId) {
      const it = await nutritionFor(foodId, grams);
      if (!it) return NextResponse.json({ success: false, error: 'Unknown food or invalid amount' }, { status: 422 });
      return NextResponse.json(toLegacy(it, 'accepted'));
    }
    if (!imageBase64) return NextResponse.json({ success: false, isFood: false, rejectionReason: 'No image data provided.' }, { status: 400 });

    const form = new FormData();
    form.append('image', dataUrlToBlob(imageBase64), 'scan.jpg');
    const r = await fetch(`${SCANNER_URL}/predict`, { method: 'POST', headers: headers(), body: form });
    if (r.status === 422) {
      const e = await r.json();
      return NextResponse.json({ success: false, isFood: false, scanStatus: 'invalid_image', rejectionReason: e.detail?.message ?? 'Invalid image.' });
    }
    if (!r.ok) return NextResponse.json({ success: false, scanStatus: 'scanner_error', error: 'Scanner service unavailable. Search for the food manually.' }, { status: 502 });
    const p = await r.json();

    const reject = ['rejected_non_food', 'ambiguous', 'low_quality_image', 'packaged_label_detected', 'model_unavailable'];
    if (reject.includes(p.status)) {
      return NextResponse.json({
        success: false, isFood: false, scanStatus: p.status, rejectionReason: p.message,
        plateTitle: p.status === 'rejected_non_food' ? 'Non-Food Image Detected' : 'Could not identify',
        identifiedItems: [], totalEstimatedNutrition: { calories: 0, protein: 0, carbs: 0, fats: 0 }, healthScore: 0, aiObservation: p.message,
      });
    }
    // accepted | needs_confirmation: return candidates; if confident, include nutrition for ONE reference serving (user can change portion).
    const top = p.candidates?.[0];
    const base = { success: true, isFood: true, scanStatus: p.status, candidates: p.candidates, portionRequired: true, needsConfirmation: p.status === 'needs_confirmation' };
    if (p.status === 'accepted' && top?.food_id) {
      const it = await nutritionFor(top.food_id);
      if (it) return NextResponse.json({ ...base, ...toLegacy(it, p.status), candidates: p.candidates });
    }
    return NextResponse.json({ ...base, plateTitle: 'Confirm your food', identifiedItems: [], totalEstimatedNutrition: { calories: 0, protein: 0, carbs: 0, fats: 0 }, healthScore: 0, aiObservation: p.message });
  } catch (e) {
    return NextResponse.json({ success: false, error: 'Scan failed' }, { status: 500 }); // do not echo internals
  }
}

function toLegacy(it: any, status: string) {
  const n: Record<string, number | undefined> = {};
  for (const k of NUT) n[k] = it.nutrients[k]?.available ? it.nutrients[k].value : undefined; // undefined => UI must show "n/a", not a default
  return {
    success: true, isFood: true, scanStatus: status, plateTitle: it.name,
    identifiedItems: [{ name: it.name, servingSize: it.grams, servingUnit: 'g', nutrition: n, confidence: undefined, healthTag: 'Reference value' }],
    totalEstimatedNutrition: n, healthScore: undefined, nutritionFlags: it.flags,
    aiObservation: `Generic reference values for ${it.grams} g of ${it.name}. Adjust the portion to match what you ate.`,
    provider: 'nutritrack_scanner',
  };
}

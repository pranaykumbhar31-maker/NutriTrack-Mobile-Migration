# Model training report

## STATUS: **ZERO-SHOT OPENCLIP VISION BACKEND ACTIVE & VERIFIED**
The service is currently running with the **OpenCLIP ViT-B-32 / laion2b_s34b_b79k** zero-shot backend (`SCANNER_BACKEND=clip_zero_shot`), enabling real-time neural vision inference without custom training:
* **Gate Model**: Zero-shot text prompt embedding distinguishing `food` vs `non_food` vs `nutrition_label`.
* **Food Classifier**: Zero-shot embedding across all 43 taxonomy classes in `configs/taxonomy.json`.
* **Live Health Check**: `/health` reports `status: "ok"`, `model_loaded: true`.
* **Verified Zero-Shot Results**:
  - Apple: 99.68% food gate, 99.78% `f-apple-fresh` classification.
  - Pizza: 95.07% food gate, 99.05% `f-pizza-slice` classification.
  - Laptop / Non-food object: 99.99% `non_food` rejection.

*(Custom supervised fine-tuning pipeline using MobileNetV3/EfficientNet remains available in `training/` for future offline ONNX export when custom datasets are assembled).*

## What *is* delivered (code, compile-checked; metrics module unit-tested)
| Piece | File | Executed here? |
|---|---|---|
| Dataset split + de-dup + manifest | `training/prepare_dataset.py` | No (py_compile only) |
| Fine-tuning (timm, class-weighted, resume) | `training/train.py`, `configs/train_gate.yaml`, `configs/train_id.yaml` | No |
| ONNX export in the exact layout the service loads | `training/export_onnx.py` | No |
| Evaluation + gate FPR + threshold calibration | `training/evaluate.py` | No |
| Metric functions (P/R/F1, confusion matrix, non-food FPR, threshold search) | `training/metrics.py` | **Yes: `tests/test_metrics.py` passes** |

## Design
* **Two models, as required:** `food_gate` (food / non_food / nutrition_label) and `food_classifier` (43 classes, `configs/taxonomy.json`, each mapped to a nutrition entry).
* **Architecture (proposed, not validated):** gate = MobileNetV3-Large; ID = EfficientNet-B0, both timm ImageNet-pretrained, fine-tuned at 224 px, AdamW + cosine LR, label smoothing, class weights. Chosen for CPU-friendly ONNX inference; not benchmarked.
* **Zero-shot alternative (no training):** `scanner/classifier/clip_backend.py` (OpenCLIP ViT-B-32 / laion2b). Unverified; accuracy on this taxonomy is unknown, and zero-shot gates are known to be weaker on hard negatives than a trained gate. Verify the weights' licence.
* **Hard negatives are mandatory** in gate data (soap, plastic fruit, medicine packs, stationery, spice-coloured objects, screenshots, plates without food, food+object scenes). See `training/DATASETS.md`.
* **Thresholds** in `scanner/config.py` (0.80/0.80/0.60) are **placeholders**, `thresholds_calibrated=false` is reported by `/health`. Calibrate on `val`, report on untouched `test`.

## Reproduce
```bash
pip install -r requirements.txt -r requirements-train.txt
python -m training.prepare_dataset --raw raw/gate --out data/gate_splits
python -m training.train --config configs/train_gate.yaml
python -m training.export_onnx --ckpt models/food_gate_run/best.pt --out models/food_gate --model-id food-gate-v0 --version 0.1.0
python -m training.evaluate --task gate --model-dir models/food_gate --data data/gate_splits/test --calibrate-on data/gate_splits/val --out reports/gate_eval.json
# repeat for the ID model with configs/train_id.yaml -> models/food_classifier
```
Acceptance bar to set *before* looking at test data (suggested, yours to decide): non-food FPR ≤ 1-2 % on a hard-negative test set; per-class recall review for visually confusable pairs (egg_boiled/egg_poached, rice_white/rice_brown, modak_steamed/modak_fried).

## Known limits (by design, not measured)
Taxonomy covers 43 foods; anything else becomes `needs_confirmation` or manual search. Mixed plates are classified as a single dominant label (no multi-item segmentation). Portion size is never inferred from the image. Nutrition accuracy is independent of classification accuracy and is **not** evaluated by this pipeline.

# nutritrack-scanner
Standalone food-scanner service for NutriTrack AI. **No trained model is included**: read `SCANNER_AI_CONTEXT.md` first (status), then `ANTIGRAVITY_INTEGRATION_GUIDE.md`.
Quick check (no extra installs): `python -m unittest discover -s tests -t .`

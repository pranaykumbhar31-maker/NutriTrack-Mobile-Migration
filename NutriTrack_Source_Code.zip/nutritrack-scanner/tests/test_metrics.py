import unittest
from training.metrics import calibrate_gate_threshold, classification_report, gate_report


class MetricsTests(unittest.TestCase):
    def test_report_known_values(self):
        r = classification_report([0, 0, 1, 1], [0, 1, 1, 1], ["a", "b"])
        self.assertAlmostEqual(r["accuracy"], 0.75); self.assertEqual(r["confusion_matrix"], [[1, 1], [0, 2]])
        self.assertAlmostEqual(r["per_class"]["b"]["precision"], 2 / 3); self.assertAlmostEqual(r["per_class"]["a"]["recall"], 0.5)

    def test_gate_fpr(self):
        g = gate_report(["food", "non_food", "non_food", "non_food"], ["food", "food", "non_food", "non_food"])
        self.assertAlmostEqual(g["non_food_false_positive_rate"], 1 / 3)

    def test_threshold_calibration(self):
        probs = [0.99, 0.97, 0.95, 0.6, 0.3, 0.2]; y = ["food", "food", "food", "non_food", "non_food", "non_food"]
        c = calibrate_gate_threshold(probs, y, 0.0)
        self.assertGreater(c["threshold"], 0.6); self.assertEqual(c["food_recall_at_threshold"], 1.0)
        self.assertIsNone(calibrate_gate_threshold([0.9999, 0.9999], ["non_food", "non_food"], 0.0)["threshold"])


if __name__ == "__main__":
    unittest.main()

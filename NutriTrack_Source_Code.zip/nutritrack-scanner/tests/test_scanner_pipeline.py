import json, unittest
from pathlib import Path
from scanner.config import get_settings
from scanner.image_quality import ImageRejected, assess_quality, decode_image
from scanner.pipeline import ScannerService
from scanner.nutrition.database import ReferenceDB
from tests.helpers import StubBackend, blurry_image, dark_image, sharp_image

S = get_settings()
DB = ReferenceDB(S.reference_db_path)
IMG = sharp_image()


def svc(gate, ident=None, boom=False):
    return ScannerService(S, StubBackend(gate, ident or [{"label": "apple", "prob": 0.9}], boom), DB)


class ImageValidation(unittest.TestCase):
    def test_rejects_garbage_empty_oversize(self):
        for data, code in [(b"", "empty_upload"), (b"not an image at all", "not_an_image"),
                           (b"\xff\xd8\xff\xe0" + b"0" * 50, None), (b"0" * (S.max_upload_bytes + 1), "too_large")]:
            with self.assertRaises(ImageRejected) as cm: decode_image(data, S)
            if code: self.assertEqual(cm.exception.code, code)

    def test_gif_unsupported(self):
        from io import BytesIO; from PIL import Image
        b = BytesIO(); Image.new("RGB", (200, 200)).save(b, "GIF")
        with self.assertRaises(ImageRejected) as cm: decode_image(b.getvalue(), S)
        self.assertEqual(cm.exception.code, "unsupported_format")

    def test_quality_flags(self):
        self.assertTrue(assess_quality(decode_image(IMG, S), S).ok)
        self.assertIn("blurry", assess_quality(decode_image(blurry_image(), S), S).issues)
        self.assertIn("too_dark", assess_quality(decode_image(dark_image(), S), S).issues)
        from tests.helpers import png_bytes; import numpy as np
        self.assertIn("too_small", assess_quality(decode_image(png_bytes(np.random.default_rng(0).integers(40, 200, (64, 64, 3))), S), S).issues)


class DecisionFlow(unittest.TestCase):
    def test_non_food_rejected(self):
        r = svc({"food": 0.03, "non_food": 0.96, "nutrition_label": 0.01}).predict(IMG)
        self.assertEqual(r["status"], "rejected_non_food"); self.assertEqual(r["candidates"], [])

    def test_mixed_or_uncertain_is_ambiguous_not_forced_to_food(self):
        r = svc({"food": 0.55, "non_food": 0.40, "nutrition_label": 0.05}).predict(IMG)
        self.assertEqual(r["status"], "ambiguous")

    def test_nutrition_label_routed(self):
        r = svc({"food": 0.05, "non_food": 0.05, "nutrition_label": 0.90}).predict(IMG)
        self.assertEqual(r["status"], "packaged_label_detected")

    def test_confident_food_accepted_with_portion_prompt(self):
        r = svc({"food": 0.97, "non_food": 0.02, "nutrition_label": 0.01}).predict(IMG)
        self.assertEqual(r["status"], "accepted")
        self.assertEqual(r["candidates"][0]["food_id"], "f-apple-fresh")
        self.assertEqual(r["portion"]["status"], "needs_user_input")
        self.assertNotIn("nutrition", r)  # classification never carries invented nutrients

    def test_low_id_confidence_needs_confirmation(self):
        r = svc({"food": 0.97, "non_food": 0.02, "nutrition_label": 0.01},
                [{"label": "dal", "prob": 0.34}, {"label": "chicken_curry", "prob": 0.30}]).predict(IMG)
        self.assertEqual(r["status"], "needs_confirmation"); self.assertEqual(len(r["candidates"]), 2)

    def test_low_quality_blocks_before_model(self):
        r = svc({"food": 0.99, "non_food": 0.0, "nutrition_label": 0.0}).predict(blurry_image())
        self.assertEqual(r["status"], "low_quality_image")

    def test_model_failure_does_not_leak(self):
        r = svc({"food": 1, "non_food": 0, "nutrition_label": 0}, boom=True).predict(IMG)
        self.assertEqual(r["status"], "model_unavailable"); self.assertNotIn("secret", json.dumps(r))

    def test_invalid_upload_reported(self):
        self.assertEqual(svc({"food": 1}).predict(b"junk")["status"], "invalid_image")

    def test_real_backend_without_weights_is_unavailable(self):
        """No model is shipped. The real ONNX backend must degrade safely, not fake predictions."""
        s = ScannerService(S, None, DB)
        self.assertIsNone(s.backend); self.assertFalse(s.health()["model_loaded"])
        self.assertEqual(s.predict(IMG)["status"], "model_unavailable")


class NutritionEndpointLogic(unittest.TestCase):
    def test_batch_and_errors(self):
        out = svc({"food": 1}).nutrition([{"food_id": "f-apple-fresh", "grams": 150}, {"food_id": "bad", "grams": 10},
                                         {"food_id": "f-banana-fresh", "amount": 2, "unit": "furlong"}])
        self.assertEqual(len(out["items"]), 1); self.assertEqual({e["code"] for e in out["errors"]}, {"unknown_food_id", "invalid_quantity"})
        self.assertIn("total", out); self.assertIn("not a measurement", out["disclaimer"])


class TaxonomyIntegrity(unittest.TestCase):
    def test_every_class_has_nutrition_entry(self):
        tax = json.loads(Path(S.taxonomy_path).read_text())["classes"]
        labels = [c["label"] for c in tax]
        self.assertEqual(len(labels), len(set(labels)))
        for c in tax: self.assertIsNotNone(DB.get(c["db_id"]), c)


if __name__ == "__main__":
    unittest.main()

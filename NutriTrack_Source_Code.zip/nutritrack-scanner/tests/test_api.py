"""API tests. Skipped automatically if fastapi/httpx are missing (they were NOT installable in the authoring sandbox)."""
import unittest
try:
    from fastapi.testclient import TestClient
    from scanner.api.app import app
    HAVE = True
except Exception:  # pragma: no cover
    HAVE = False
from tests.helpers import sharp_image


@unittest.skipUnless(HAVE, "fastapi/httpx not installed")
class ApiTests(unittest.TestCase):
    def setUp(self): self.c = TestClient(app)

    def test_health(self):
        r = self.c.get("/health"); self.assertEqual(r.status_code, 200); self.assertIn("model_loaded", r.json())

    def test_predict_garbage_422(self):
        r = self.c.post("/predict", files={"image": ("x.png", b"junk", "image/png")}); self.assertEqual(r.status_code, 422)

    def test_predict_without_model_is_graceful(self):
        r = self.c.post("/predict", files={"image": ("x.png", sharp_image(), "image/png")})
        self.assertEqual(r.status_code, 200); self.assertIn(r.json()["status"], {"model_unavailable", "accepted", "needs_confirmation", "ambiguous", "rejected_non_food"})

    def test_nutrition_ok_and_validation(self):
        r = self.c.post("/nutrition", json={"items": [{"food_id": "f-apple-fresh", "grams": 182}]})
        self.assertEqual(r.status_code, 200); self.assertAlmostEqual(r.json()["items"][0]["nutrients"]["calories"]["value"], 95, delta=1)
        self.assertEqual(self.c.post("/nutrition", json={"items": [{"food_id": "f-apple-fresh"}]}).status_code, 422)
        self.assertEqual(self.c.post("/nutrition", json={"items": [{"food_id": "zzz", "grams": 5}]}).status_code, 422)
        self.assertEqual(self.c.post("/nutrition", json={"items": [{"food_id": "f-apple-fresh", "grams": -3}]}).status_code, 422)

    def test_search_and_servings(self):
        self.assertTrue(self.c.get("/foods/search", params={"q": "dosa"}).json()["results"])
        self.assertEqual(self.c.get("/foods/nope/servings").status_code, 404)


if __name__ == "__main__":
    unittest.main()

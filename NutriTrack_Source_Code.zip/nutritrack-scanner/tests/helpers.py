"""Test fixtures. StubBackend is a TEST DOUBLE that returns scripted probabilities.
It is NOT a model and says nothing about real recognition accuracy."""
from io import BytesIO
import numpy as np
from PIL import Image
from scanner.classifier.base import GateResult, IdResult


def png_bytes(arr: np.ndarray, fmt="PNG") -> bytes:
    b = BytesIO(); Image.fromarray(arr.astype("uint8")).save(b, fmt); return b.getvalue()


def sharp_image(size=256, seed=0) -> bytes:
    rng = np.random.default_rng(seed)
    return png_bytes(rng.integers(40, 215, (size, size, 3)))


def blurry_image(size=256) -> bytes:
    g = np.linspace(100, 140, size, dtype=np.float32)
    return png_bytes(np.stack([np.tile(g, (size, 1))] * 3, -1))


def dark_image(size=256, seed=1) -> bytes:
    rng = np.random.default_rng(seed)
    return png_bytes(rng.integers(0, 20, (size, size, 3)))


class StubBackend:
    def __init__(self, gate, ident, boom=False):
        self.gate, self.ident, self.boom = gate, ident, boom

    def predict_gate(self, img):
        if self.boom: raise RuntimeError("secret internal path /opt/model.onnx")
        return GateResult(self.gate, "stub")

    def predict_id(self, img, top_k=5):
        return IdResult(self.ident, "stub")

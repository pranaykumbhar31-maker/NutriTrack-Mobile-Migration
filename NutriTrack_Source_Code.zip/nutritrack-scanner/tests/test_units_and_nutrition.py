import unittest
from scanner.config import get_settings
from scanner.nutrition.database import ReferenceDB
from scanner.nutrition import calculator, matching
from scanner.nutrition.units import to_grams, UnitError

DB = ReferenceDB(get_settings().reference_db_path)


class UnitTests(unittest.TestCase):
    def test_mass(self):
        self.assertAlmostEqual(to_grams(1, "kg").grams, 1000)
        self.assertAlmostEqual(to_grams(1, "oz").grams, 28.3495, 3)
        self.assertAlmostEqual(to_grams(1, "lb").grams, 453.592, 2)
        self.assertAlmostEqual(to_grams(500, "mg").grams, 0.5)

    def test_volume_flags_assumed_density(self):
        r = to_grams(1, "cup")
        self.assertAlmostEqual(r.grams, 240); self.assertTrue(r.assumed_density)
        self.assertFalse(to_grams(1, "cup", density_g_per_ml=0.5).assumed_density)
        self.assertAlmostEqual(to_grams(1, "cup", density_g_per_ml=0.5).grams, 120)

    def test_bad_inputs(self):
        for amt, unit in [(0, "g"), (-5, "g"), (float("nan"), "g"), (1e9, "g"), (5, "bushel"), (None, "g")]:
            with self.assertRaises(UnitError): to_grams(amt, unit)


class CalculatorTests(unittest.TestCase):
    def test_apple_matches_reference_serving(self):
        r = calculator.compute(DB, "f-apple-fresh", 182, "g")
        self.assertAlmostEqual(r["nutrients"]["calories"]["value"], 95, delta=1)
        self.assertAlmostEqual(r["nutrients"]["carbs"]["value"], 25.1, delta=0.2)

    def test_linear_scaling(self):
        a = calculator.compute(DB, "f-chicken-breast", 100)["nutrients"]["protein"]["value"]
        b = calculator.compute(DB, "f-chicken-breast", 250)["nutrients"]["protein"]["value"]
        self.assertAlmostEqual(b, a * 2.5, delta=0.1)

    def test_missing_nutrient_is_unavailable_not_invented(self):
        r = calculator.compute(DB, "f-apple-fresh", 100)
        # the legacy table has no vitamin C for apple; must stay null (legacy code would have invented values)
        vc = r["nutrients"]["vitaminC"]
        self.assertIsNone(vc["value"]); self.assertFalse(vc["available"])
        self.assertTrue(any(k for k in ["fiber", "sugar"] if r["nutrients"][k]["available"] in (True, False)))

    def test_fiber_not_defaulted_when_absent(self):
        for f in DB.foods:
            r = calculator.compute(DB, f["id"], 100)
            src = f["per_100g"]["fiber"]
            self.assertEqual(r["nutrients"]["fiber"]["value"], None if src is None else round(src, 1))

    def test_servings_and_flags(self):
        r = calculator.compute(DB, "f-egg-boiled", 0, servings=2)
        self.assertAlmostEqual(r["grams"], 100)
        self.assertIn("reference_values_not_independently_verified", r["flags"])
        comp = calculator.compute(DB, "f-masala-dosa", 200)
        self.assertIn("composite_recipe_values_vary_by_recipe", comp["flags"])
        self.assertEqual(comp["reference_type"], "composite_recipe")

    def test_unknown_food_and_bad_servings(self):
        with self.assertRaises(KeyError): calculator.compute(DB, "nope", 100)
        with self.assertRaises(UnitError): calculator.compute(DB, "f-egg-boiled", 0, servings=0)

    def test_volume_flag(self):
        r = calculator.compute(DB, "f-coffee-latte", 1, "cup")
        self.assertIn("volume_converted_with_assumed_density_1g_per_ml", r["flags"])

    def test_total_marks_incomplete(self):
        items = [calculator.compute(DB, "f-apple-fresh", 100), calculator.compute(DB, "f-banana-fresh", 100)]
        t = calculator.total(items)
        self.assertAlmostEqual(t["calories"]["value"], sum(i["nutrients"]["calories"]["value"] for i in items), delta=0.6)
        self.assertFalse(t["vitaminC"]["complete"]); self.assertIsNone(t["vitaminC"]["value"])

    def test_atwater_consistency_of_reference_data(self):
        for f in DB.foods:
            p = f["per_100g"]; atw = 4 * p["protein"] + 4 * p["carbs"] + 9 * p["fats"]
            self.assertLessEqual(abs(atw - p["calories"]), max(10, 0.15 * p["calories"]), f["id"])


class MatchingTests(unittest.TestCase):
    def test_finds_reasonable(self):
        self.assertEqual(matching.search(DB, "paneer butter masala")[0]["id"], "f-paneer-butter-masala")
        self.assertEqual(matching.search(DB, "apple")[0]["id"], "f-apple-fresh")

    def test_no_arbitrary_fallback(self):
        self.assertEqual(matching.search(DB, "zzzxqv"), [])
        self.assertEqual(matching.search(DB, ""), [])


if __name__ == "__main__":
    unittest.main()

"""Convert the website's legacy foodDatabase.ts export into the scanner reference schema.

The legacy table stores *per-serving* values with inconsistent serving units. This script
normalises to per-100 g ONLY where the serving weight can be derived, and records how it was
derived. Nutrients that the legacy table does not contain stay null (never defaulted).

Usage:  python tools/convert_legacy_db.py tools/legacy_food_database.json data/reference_foods.json
"""
import json, re, sys
from collections import OrderedDict

NUTRIENTS = ["calories", "protein", "carbs", "fats", "fiber", "sugar", "sodium",
             "potassium", "calcium", "iron", "vitaminA", "vitaminC"]
LEGACY_GRAM_UNITS = {"cup", "half cup", "half avocado", "katori / bowl", "serving",
                     "cooked bowl", "bowl", "fillet"}


def derive_grams(item):
    size, unit = item["servingSize"], item["servingUnit"].lower().strip()
    if unit in ("g", "ml"):
        return size, "explicit_" + unit
    m = re.search(r"(\d+(?:\.\d+)?)\s*(g|ml)\b", unit)
    if m:
        return float(m.group(1)), "explicit_in_unit_" + m.group(2)
    if unit == "large egg":
        return 50.0 * size, "usda_large_egg_50g"
    if unit in LEGACY_GRAM_UNITS and size > 10:
        return float(size), "legacy_servingSize_interpreted_as_grams_UNVERIFIED"
    return None, "unknown"


def main(src, dst):
    legacy = json.load(open(src))
    seen, out, notes = OrderedDict(), [], []
    for it in legacy:
        if it["id"] in seen:
            notes.append(f"duplicate id {it['id']} skipped (legacy 'first match wins' behaviour kept)")
            continue
        seen[it["id"]] = 1
        grams, basis = derive_grams(it)
        per100 = {n: None for n in NUTRIENTS}
        if grams:
            for n in NUTRIENTS:
                v = it.get(n)
                per100[n] = None if v is None else round(v * 100.0 / grams, 2)
        atw = None
        if per100["calories"] is not None:
            atw = round(4 * per100["protein"] + 4 * per100["carbs"] + 9 * per100["fats"], 1)
        unit_l = it["servingUnit"].lower()
        is_liquid = "ml" in basis or "ml)" in unit_l
        composite = it["category"] == "composite" or "plate" in unit_l or "thali" in unit_l
        out.append({
            "id": it["id"], "name": it["name"], "category": it["category"],
            "cuisine": it.get("cuisine"),
            "kind": "composite_recipe" if composite else "generic_reference",
            "is_liquid": is_liquid,
            "per_100g": per100,
            "serving": {"grams": grams, "label": f"{it['servingSize']} {it['servingUnit']}", "weight_basis": basis},
            "atwater_kcal_per_100g": atw,
            "source": "legacy_nutritrack_foodDatabase_ts",
            "source_verified": False,
        })
    json.dump({"schema_version": 1,
               "source_note": "Seeded from the website's legacy table. Values are NOT independently verified against USDA/IFCT. Replace/extend with tools/import_usda_fdc.py.",
               "foods": out, "conversion_notes": notes}, open(dst, "w"), indent=1)
    print(f"wrote {len(out)} foods, {sum(1 for f in out if f['per_100g']['calories'] is None)} without usable weight; notes={notes}")


if __name__ == "__main__":
    main(*sys.argv[1:3])

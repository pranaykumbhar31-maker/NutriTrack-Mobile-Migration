"""Import generic reference foods from USDA FoodData Central into data/reference_foods.json format.
UNEXECUTED (no network in authoring sandbox). Needs env FDC_API_KEY (free: https://fdc.nal.usda.gov/api-key-signup.html).
Nutrient IDs below are from memory of the FDC schema: VERIFY against a real response before trusting.

  python tools/import_usda_fdc.py --queries "apple raw" "banana raw" --out data/usda_import.json
Prefer data types 'Foundation' / 'SR Legacy' for generic foods. Branded foods are product-specific: keep kind='branded_product'.
"""
import argparse, json, os, urllib.parse, urllib.request

NID = {"calories": 1008, "protein": 1003, "carbs": 1005, "fats": 1004, "fiber": 1079, "sugar": 2000,
       "sodium": 1093, "potassium": 1092, "calcium": 1087, "iron": 1089, "vitaminA": 1106, "vitaminC": 1162}


def get(url):
    with urllib.request.urlopen(url, timeout=20) as r:
        return json.load(r)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--queries", nargs="+", required=True); ap.add_argument("--out", required=True)
    a = ap.parse_args(); key = os.environ["FDC_API_KEY"]; foods = []
    for q in a.queries:
        s = get("https://api.nal.usda.gov/fdc/v1/foods/search?" + urllib.parse.urlencode({"query": q, "pageSize": 1, "dataType": "Foundation,SR Legacy", "api_key": key}))
        if not s.get("foods"): print("no result:", q); continue
        f = s["foods"][0]; vals = {n["nutrientId"]: n["value"] for n in f.get("foodNutrients", []) if "value" in n}
        foods.append({"id": f"usda-{f['fdcId']}", "name": f["description"], "category": "unknown", "cuisine": None, "kind": "generic_reference", "is_liquid": False,
                      "per_100g": {k: vals.get(i) for k, i in NID.items()}, "serving": {"grams": None, "label": "100 g", "weight_basis": "per_100g"},
                      "atwater_kcal_per_100g": None, "source": f"USDA FDC {f.get('dataType')} fdcId={f['fdcId']}", "source_verified": True})
    json.dump({"schema_version": 1, "source_note": "USDA FoodData Central import", "foods": foods}, open(a.out, "w"), indent=1)


if __name__ == "__main__":
    main()
